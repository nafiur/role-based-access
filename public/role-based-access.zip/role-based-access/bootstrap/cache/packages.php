<?php return array (
  'laravel/breeze' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Breeze\\BreezeServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
  'php-flasher/flasher-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Flasher\\Laravel\\FlasherServiceProvider',
    ),
    'aliases' => 
    array (
      'Flasher' => 'Flasher\\Laravel\\Facade\\Flasher',
    ),
  ),
  'php-flasher/flasher-noty-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Flasher\\Noty\\Laravel\\FlasherNotyServiceProvider',
    ),
    'aliases' => 
    array (
      'Noty' => 'Flasher\\Noty\\Laravel\\Facade\\Noty',
    ),
  ),
  'php-flasher/flasher-notyf-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Flasher\\Notyf\\Laravel\\FlasherNotyfServiceProvider',
    ),
    'aliases' => 
    array (
      'Notyf' => 'Flasher\\Notyf\\Laravel\\Facade\\Notyf',
    ),
  ),
  'php-flasher/flasher-sweetalert-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Flasher\\SweetAlert\\Laravel\\FlasherSweetAlertServiceProvider',
    ),
    'aliases' => 
    array (
      'SweetAlert' => 'Flasher\\SweetAlert\\Laravel\\Facade\\SweetAlert',
    ),
  ),
  'php-flasher/flasher-toastr-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Flasher\\Toastr\\Laravel\\FlasherToastrServiceProvider',
    ),
    'aliases' => 
    array (
      'Toastr' => 'Flasher\\Toastr\\Laravel\\Facade\\Toastr',
    ),
  ),
);